﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.AxDwgViewX1 = New AxDWGVIEWXLib.AxDwgViewX()
        CType(Me.AxDwgViewX1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AxDwgViewX1
        '
        Me.AxDwgViewX1.Enabled = True
        Me.AxDwgViewX1.Location = New System.Drawing.Point(12, 22)
        Me.AxDwgViewX1.Name = "AxDwgViewX1"
        Me.AxDwgViewX1.OcxState = CType(resources.GetObject("AxDwgViewX1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDwgViewX1.Size = New System.Drawing.Size(458, 319)
        Me.AxDwgViewX1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(582, 459)
        Me.Controls.Add(Me.AxDwgViewX1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.AxDwgViewX1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents AxDwgViewX1 As AxDWGVIEWXLib.AxDwgViewX

End Class
